export const STATUS_SUCCESS = 1;
export const STATUS_FAIL = 0;
export const STATUS_BAD_REQUEST = 400;
export const STATUS_NOT_FOUND = 404;
