import { RowDataPacket } from "mysql2";

export interface MySQLError extends Error {
  code?: string;
  errno?: number;
  sqlState?: string;
  sqlMessage?: string;
}

export interface SelectUserByEmail extends RowDataPacket {
  email: string;
  password: string;
  name: string;
  role: number;
}

export interface Prefix extends RowDataPacket {
  prefix: string;
}

//number is success, string is sql error, null is server error 500
export type InsertPurchaseOrder = (
  purchaseOrder: string,
  orderRef: string
) => Promise<number | string | null>;
